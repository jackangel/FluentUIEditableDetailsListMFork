"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
;